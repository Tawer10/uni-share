﻿    using System;

    class FloydWarshall
    {
        static int INF = 100000000;

        public static void Main()
        {
            int[,] graph = new int[,]
            {
                { 0, 2, -5, INF, INF, INF, 4 },
                { 1, 0, INF, 5, INF, INF, INF },
                { 3, INF, 0, INF, INF, -2, 6 },
                { 7, 8, INF, 0, INF, INF, -4 },
                { INF, -1, INF, 11, 0, INF, 9 },
                { 10, INF, 12, INF, INF, 0, INF },
                { -3, INF, INF, INF, INF, INF, 0 }
            };

            int vertices = graph.GetLength(0);
            int[,] dist = FloydWarshallAlgorithm(graph, vertices);

            PrintSolution(dist, vertices);
        }

        static int[,] FloydWarshallAlgorithm(int[,] graph, int vertices)
        {
            int[,] dist = new int[vertices, vertices];
            int[,] next = new int[vertices, vertices];

            for (int i = 0; i < vertices; i++)
                for (int j = 0; j < vertices; j++)
                    dist[i, j] = graph[i, j];

            for (int k = 0; k < vertices; k++)
            {
                for (int i = 0; i < vertices; i++)
                {
                    for (int j = 0; j < vertices; j++)
                    {
                        if(dist[i,k] != 1e8 && dist[k, j] != 1e8 && i != j)
                        {
                            dist[i,j] = Math.Min(dist[i, j], dist[i, k] + dist[k, j]);
                        }
                    }
                }
            }

            return dist;
        }

        static void PrintSolution(int[,] dist, int vertices)
        {
            Console.WriteLine("Матриця найкоротших шляхів між вершинами:");
            for (int i = 0; i < vertices; i++)
            {
                for (int j = 0; j < vertices; j++)
                {
                    if (dist[i, j] == INF)
                        Console.Write("NaN ");
                    else
                        Console.Write(dist[i, j] + " ");
                }
                Console.WriteLine();
            }
        }
    }
