﻿using System;
using System.IO;
using QuickGraph;
using QuickGraph.Graphviz;
using QuickGraph.Algorithms;
using QuickGraph.Graphviz.Dot;

public sealed class FileDotEngine : IDotEngine
{
    public string Run(GraphvizImageType imageType, string dot, string outputFileName)
    {
        string output = outputFileName;

        // Write the dot content to a file
        File.WriteAllText(output, dot);

        // Assuming Graphviz 'dot' is installed and available in the PATH
        var args = string.Format(@"{0} -Tpng -o {1}", output, outputFileName.Replace(".dot", ".png"));
        
        // Run the 'dot' command to generate the PNG image
        System.Diagnostics.Process.Start("dot.exe", args);

        return output;
    }
}

class Program
{
    static void Main()
    {
        // Adjacency matrix
        int[,] adjacencyMatrix = {
            {0, 1, 1, 1, 1},
            {0, 0, 1, 1, 1},
            {0, 0, 0, 1, 1},
            {0, 0, 0, 0, 1},
            {0, 0, 0, 0, 0},
        };

        int vertices = adjacencyMatrix.GetLength(0);

        // Create a new graph (undirected, integer vertices)
        var graph = new AdjacencyGraph<int, Edge<int>>();

        // Add vertices to the graph
        for (int i = 0; i < vertices; i++)
        {
            graph.AddVertex(i);
        }

        // Add edges based on adjacency matrix
        for (int i = 0; i < vertices; i++)
        {
            for (int j = 0; j < vertices; j++)
            {
                if (adjacencyMatrix[i, j] == 1 && i < j) // Avoid adding duplicate edges for undirected graph
                {
                    graph.AddEdge(new Edge<int>(i, j));
                }
            }
        }

        // Define the output file paths
        string dotFilePath = "graph.dot";
        string outputFilePath = "graph.png";

        // Create the Graphviz algorithm and generate the dot file
        var graphviz = new GraphvizAlgorithm<int, Edge<int>>(graph);

        // Generate .dot content using the custom FileDotEngine
        var fileDotEngine = new FileDotEngine();
        string dotContent = graphviz.Generate();

        // Run the engine to create the PNG image
        fileDotEngine.Run(GraphvizImageType.Png, dotContent, dotFilePath);
        Console.WriteLine("Graph image saved as 'graph.png'.");
    }
}
