﻿using System;
using System.IO.Pipes;
using System.Text;
using System.Threading;

class PipeCommunication
{
    static void Main(string[] args)
    {
        // Start the processes in separate threads
        Thread process1Thread = new Thread(Process1);
        Thread process2Thread = new Thread(Process2);
        Thread process3Thread = new Thread(Process3);

        // Start each thread
        process1Thread.Start();
        process2Thread.Start();
        process3Thread.Start();

        // Wait for all threads to complete
        process1Thread.Join();
        process2Thread.Join();
        process3Thread.Join();
    }

    static void Process1()
    {
        Console.WriteLine("Process 1 is starting...");

        // Send message to Process 2
        using (NamedPipeClientStream pipeClient2 = new NamedPipeClientStream(".", "Pipe2", PipeDirection.Out))
        {
            Thread.Sleep(500); // Ensure Process 2's server is ready
            Console.WriteLine("Process 1 connecting to Process 2...");
            pipeClient2.Connect();
            string messageToProcess2 = "Hello from Process 1 to Process 2!";
            byte[] buffer2 = Encoding.UTF8.GetBytes(messageToProcess2);
            pipeClient2.Write(buffer2, 0, buffer2.Length);
            Console.WriteLine("Process 1 sent to Process 2: " + messageToProcess2);
        }

        // Send message to Process 3
        using (NamedPipeClientStream pipeClient3 = new NamedPipeClientStream(".", "Pipe3", PipeDirection.Out))
        {
            Thread.Sleep(500); // Ensure Process 3's server is ready
            Console.WriteLine("Process 1 connecting to Process 3...");
            pipeClient3.Connect();
            string messageToProcess3 = "Hello from Process 1 to Process 3!";
            byte[] buffer3 = Encoding.UTF8.GetBytes(messageToProcess3);
            pipeClient3.Write(buffer3, 0, buffer3.Length);
            Console.WriteLine("Process 1 sent to Process 3: " + messageToProcess3);
        }
    }

    static void Process2()
    {
        Console.WriteLine("Process 2 is starting...");

        // Server to receive messages from Process 1
        using (NamedPipeServerStream pipeServer2 = new NamedPipeServerStream("Pipe2", PipeDirection.In))
        {
            Console.WriteLine("Process 2 waiting for Process 1...");
            pipeServer2.WaitForConnection();
            byte[] buffer2 = new byte[256];
            int bytesRead2 = pipeServer2.Read(buffer2, 0, buffer2.Length);
            string message2 = Encoding.UTF8.GetString(buffer2, 0, bytesRead2);
            Console.WriteLine("Process 2 received from Process 1: " + message2);
        }

        // Server to receive messages from Process 3
        using (NamedPipeServerStream pipeServer3 = new NamedPipeServerStream("Pipe3", PipeDirection.In))
        {
            Console.WriteLine("Process 2 waiting for Process 3...");
            pipeServer3.WaitForConnection();
            byte[] buffer3 = new byte[256];
            int bytesRead3 = pipeServer3.Read(buffer3, 0, buffer3.Length);
            string message3 = Encoding.UTF8.GetString(buffer3, 0, bytesRead3);
            Console.WriteLine("Process 2 received from Process 3: " + message3);
        }
    }

    static void Process3()
    {
        Console.WriteLine("Process 3 is starting...");

        // Wait a small delay to allow servers to set up
        Thread.Sleep(500);

        // Client sends message to Process 1
        using (NamedPipeClientStream pipeClient1 = new NamedPipeClientStream(".", "Pipe1", PipeDirection.Out))
        {
            pipeClient1.Connect();
            string messageToProcess1 = "Hello from Process 3 to Process 1!";
            byte[] buffer1 = Encoding.UTF8.GetBytes(messageToProcess1);
            pipeClient1.Write(buffer1, 0, buffer1.Length);
            Console.WriteLine("Process 3 sent to Process 1: " + messageToProcess1);
        }

        // Client sends message to Process 2
        using (NamedPipeClientStream pipeClient2 = new NamedPipeClientStream(".", "Pipe2", PipeDirection.Out))
        {
            Console.WriteLine("Process 3 connecting to Process 2...");
            pipeClient2.Connect();
            string messageToProcess2 = "Hello from Process 3 to Process 2!";
            byte[] buffer2 = Encoding.UTF8.GetBytes(messageToProcess2);
            pipeClient2.Write(buffer2, 0, buffer2.Length);
            Console.WriteLine("Process 3 sent to Process 2: " + messageToProcess2);
        }

        // Server for receiving messages from itself (Process 3)
        using (NamedPipeServerStream pipeServer3 = new NamedPipeServerStream("Pipe3", PipeDirection.In))
        {
            Console.WriteLine("Process 3 waiting for itself...");
            pipeServer3.WaitForConnection();
            Console.WriteLine("Process 3 connected to itself.");

            byte[] buffer3 = new byte[256];
            int bytesRead3 = pipeServer3.Read(buffer3, 0, buffer3.Length);
            string message3 = Encoding.UTF8.GetString(buffer3, 0, bytesRead3);
            Console.WriteLine("Process 3 received from itself: " + message3);
        }

        // Client sends message to itself
        using (NamedPipeClientStream pipeClient3 = new NamedPipeClientStream(".", "Pipe3", PipeDirection.Out))
        {
            Thread.Sleep(500); // Added delay before connecting to itself
            pipeClient3.Connect();
            string messageToProcess3 = "Hello from Process 3 to itself!";
            byte[] buffer3 = Encoding.UTF8.GetBytes(messageToProcess3);
            pipeClient3.Write(buffer3, 0, buffer3.Length);
            Console.WriteLine("Process 3 sent to itself: " + messageToProcess3);
        }
    }
}
