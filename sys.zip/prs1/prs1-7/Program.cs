﻿using System;
using System.Reflection;
using System.Threading;

namespace Progr2
{
    public class Program
    {
        const int N = 5; // Number of threads
        static long[] counts;
        static bool finish;

        static void SomeFunc()
        {
            Thread.Sleep(100); // Simulate some work
            Console.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId} finished work.");
        }

        static void ThreadFunc(object iThread)
        {
            while (true)
            {
                if (finish)
                    break;
                counts[(int)iThread]++;
            }
        }

        static void Main()
        {
            Console.Title = "Информация о главном потоке программы";

            // --- Info about the main thread ---
            Thread mainThread = Thread.CurrentThread;
            mainThread.Name = "MyThread";

            Console.WriteLine($@"Имя домена приложения: {Thread.GetDomain().FriendlyName}
Имя потока: {mainThread.Name}
Запущен ли поток? {mainThread.IsAlive}
Приоритет потока: {mainThread.Priority}
Состояние потока: {mainThread.ThreadState}");

            Console.WriteLine("\n--- Свойства текущего потока через Reflection ---");
            foreach (PropertyInfo p in mainThread.GetType().GetProperties())
            {
                Console.WriteLine($"{p.Name}: {p.GetValue(mainThread, null)}");
            }

            // --- Create and Start multiple Threads ---
            Console.WriteLine("\n--- Создание массива потоков ---");
            Thread[] arThr = new Thread[N];

            for (int i = 0; i < arThr.Length; i++)
            {
                arThr[i] = new Thread(SomeFunc);
                arThr[i].Start();
            }

            Thread.Sleep(500); // Small delay to let threads start

            // --- Display info about each thread ---
            Console.WriteLine("\n--- Информация о потоках ---");
            for (int i = 0; i < arThr.Length; i++)
            {
                Console.WriteLine($"Thread Id: {arThr[i].ManagedThreadId}, Name: {arThr[i].Name}, IsAlive: {arThr[i].IsAlive}");
            }

            // --- PRIORITY TESTING ---

            Console.WriteLine("\n--- Тестирование приоритета потоков ---");
            counts = new long[5];
            Thread[] t = new Thread[5];

            for (int i = 0; i < t.Length; i++)
            {
                t[i] = new Thread(ThreadFunc);
                switch (i)
                {
                    case 0: t[i].Priority = ThreadPriority.Lowest; break;
                    case 1: t[i].Priority = ThreadPriority.BelowNormal; break;
                    case 2: t[i].Priority = ThreadPriority.Normal; break;
                    case 3: t[i].Priority = ThreadPriority.AboveNormal; break;
                    case 4: t[i].Priority = ThreadPriority.Highest; break;
                }
            }

            // Start threads
            for (int i = 0; i < t.Length; i++)
                t[i].Start(i);

            // Let them run for 10 seconds
            Thread.Sleep(10000);

            // Signal threads to finish
            finish = true;

            // Wait for all threads to finish
            for (int i = 0; i < t.Length; i++)
                t[i].Join();

            // Display results
            for (int i = 0; i < t.Length; i++)
            {
                ThreadPriority priority = ThreadPriority.Normal;
                switch (i)
                {
                    case 0: priority = ThreadPriority.Lowest; break;
                    case 1: priority = ThreadPriority.BelowNormal; break;
                    case 2: priority = ThreadPriority.Normal; break;
                    case 3: priority = ThreadPriority.AboveNormal; break;
                    case 4: priority = ThreadPriority.Highest; break;
                }
                Console.WriteLine($"Thread with priority {priority,15}, Counts: {counts[i]}");
            }

            Console.ReadLine();
        }
    }
}
