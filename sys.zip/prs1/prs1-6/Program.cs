﻿using System;
using System.Reflection;
using System.Threading;

namespace progr2
{
    class Program
    {
        const int N = 5; // You can change the number of threads here

        static void SomeFunc()
        {
            Thread.Sleep(100); // Simulate some work
            Console.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId} finished work.");
        }

        static void Main()
        {
            Console.Title = "Информация о главном потоке программы";

            // --- Info about the main thread ---
            Thread mainThread = Thread.CurrentThread;
            mainThread.Name = "MyThread";

            Console.WriteLine($@"Имя домена приложения: {Thread.GetDomain().FriendlyName}
ID контекста: {Thread.CurrentThread.ManagedThreadId}
Имя потока: {mainThread.Name}
Запущен ли поток? {mainThread.IsAlive}
Приоритет потока: {mainThread.Priority}
Состояние потока: {mainThread.ThreadState}");

            Console.WriteLine("\n--- Свойства текущего потока через Reflection ---");
            foreach (PropertyInfo p in mainThread.GetType().GetProperties())
            {
                Console.WriteLine($"{p.Name}: {p.GetValue(mainThread, null)}");
            }

            // --- Create and Start multiple Threads ---
            Console.WriteLine("\n--- Создание массива потоков ---");
            Thread[] arThr = new Thread[N];

            for (int i = 0; i < arThr.Length; i++)
            {
                arThr[i] = new Thread(SomeFunc);
                arThr[i].Start();
            }

            Thread.Sleep(500); // Small delay to let threads start

            // --- Display info about each thread ---
            Console.WriteLine("\n--- Информация о потоках ---");
            for (int i = 0; i < arThr.Length; i++)
            {
                Console.WriteLine($"Thread Id: {arThr[i].ManagedThreadId}, Name: {arThr[i].Name}, IsAlive: {arThr[i].IsAlive}");
            }

            Console.ReadLine();
        }
    }
}
