﻿using System;
using System.Threading;

namespace ThreadLocalExample
{
    public class Data
    {
        public static int sharedVar;
        
        // Making localVar public so it can be accessed outside the class
        [ThreadStatic] 
        public static int localVar;
    }

    public class ThreadWork
    {
        private string sharedWord;

        public ThreadWork(string secretWord)
        {
            sharedWord = secretWord ?? throw new ArgumentNullException(nameof(secretWord));  // Ensure secretWord is not null
        }

        public void Run()
        {
            Save(sharedWord);
            Thread.Sleep(500);
            Show();
        }

        private void Save(string s)
        {
            LocalDataStoreSlot slot = Thread.GetNamedDataSlot("Secret");
            Thread.SetData(slot, s);
        }

        private void Show()
        {
            LocalDataStoreSlot slot = Thread.GetNamedDataSlot("Secret");
            string secretWord = (string)Thread.GetData(slot);
            Console.WriteLine("Thread {0}, secret word: {1}, shared word: {2}",
                Thread.CurrentThread.ManagedThreadId,
                secretWord, sharedWord);
        }
    }

    class Program
    {
        // Fixing the parameter type to handle nullable values
        static void threadFunc(object? i)
        {
            if (i == null) return; // Preventing null references

            Console.WriteLine("Thread {0}: Before changing.. Shared: {1}, local: {2}",
                i, Data.sharedVar, Data.localVar);
            Data.sharedVar = (int)i;
            Data.localVar = (int)i;
            Console.WriteLine("Thread {0}: After changing.. Shared: {1}, local: {2}",
                i, Data.sharedVar, Data.localVar);
        }

        static void Main()
        {
            // Correcting the thread creation and ensuring the value passed is valid
            Thread t1 = new Thread(threadFunc);
            Thread t2 = new Thread(threadFunc);
            Data.sharedVar = 3; 
            Data.localVar = 3;
            t1.Start(1); 
            t2.Start(2);
            t1.Join(); 
            t2.Join();

            // ThreadLocal<T> example
            Console.WriteLine("\n--- ThreadLocal<T> Example ---");
            ThreadLocal<int> localSum = new ThreadLocal<int>(() => 0);
            Thread t1_2 = new Thread(() =>
            {
                for (int i = 0; i < 10; i++)
                    localSum.Value++;
                Console.WriteLine(localSum.Value);
            });
            Thread t2_2 = new Thread(() =>
            {
                for (int i = 0; i < 10; i++)
                    localSum.Value--;
                Console.WriteLine(localSum.Value);
            });
            t1_2.Start();
            t2_2.Start();
            t1_2.Join();
            t2_2.Join();
            Console.WriteLine("Main thread final value: " + localSum.Value);

            // Thread Local Slots example
            Console.WriteLine("\n--- Thread Local Slots Example ---");
            ThreadWork thr1 = new ThreadWork("one");
            ThreadWork thr2 = new ThreadWork("two");
            ThreadWork thr3 = new ThreadWork("three");

            new Thread(() => thr1.Run()).Start();
            new Thread(() => thr2.Run()).Start();
            new Thread(() => thr3.Run()).Start();
            Thread.Sleep(1000); // Allow threads to finish work

            Console.ReadLine(); // Pause to view the output
        }
    }
}
