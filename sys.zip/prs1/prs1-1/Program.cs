﻿using System;
using System.Windows.Forms;
using System.Threading;

namespace Progr2
{
    public class MyThread
    {
        public void ThreadNumbers()
        {
            // Информация о потоке
            Console.WriteLine("{0} поток использует метод ThreadNumbers", Thread.CurrentThread.Name);
            // Выводим числа
            Console.Write("Числа: ");
            for (int i = 0; i < 10; i++)
            {
                Console.Write(i + ", ");
                Thread.Sleep(1000);
            }
            Console.WriteLine();
        }
    }

    public class ThreadClass
    {
        private string greeting;
        public ThreadClass(string sGreeting)
        {
            greeting = sGreeting;
        }
        public void Run()
        {
            Console.WriteLine(greeting);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // ----------- First part: asking user how many threads -----------
            string number = "2";
            Thread mythread = Thread.CurrentThread;
            mythread.Name = "Первичный";

            // Информация о главном потоке
            Console.WriteLine("--> {0} главный поток", Thread.CurrentThread.Name);

            MyThread mt = new MyThread();
            switch (number)
            {
                case "1":
                    mt.ThreadNumbers();
                    break;
                case "2":
                    // Создаем дополнительный поток
                    Thread backgroundThread = new Thread(new ThreadStart(mt.ThreadNumbers));
                    backgroundThread.Name = "Вторичный";
                    backgroundThread.Start();
                    break;
                default:
                    Console.WriteLine("использую 1 поток");
                    goto case "1";
            }
            MessageBox.Show("Сообщение ...", "Работа в другом потоке");

            // ----------- Second part: Threads with static method, lambda, class method -----------
            Thread thr1 = new Thread(LocalWorkItem);
            thr1.Start();

            Thread thr2 = new Thread(() =>
            {
                Console.WriteLine("Hello from lambda-expression");
            });
            thr2.Start();

            ThreadClass thrClass = new ThreadClass("Hello from thread-class");
            Thread thr3 = new Thread(thrClass.Run);
            thr3.Start();

            // ----------- Third part: Main and child thread interaction -----------
            Thread childThread = new Thread(ThreadFunction);
            childThread.Start();

            int mainCount = 3;
            while (mainCount > 0)
            {
                Console.WriteLine("Это главный поток программы!");
                --mainCount;
            }

            // ----------- Fourth part: Using Join to synchronize threads -----------
            Thread joinThr1 = new Thread(() =>
            {
                for (int i = 0; i < 5; i++)
                    Console.Write("A");
            });

            Thread joinThr2 = new Thread(() =>
            {
                for (int i = 0; i < 5; i++)
                    Console.Write("B");
            });

            Thread joinThr3 = new Thread(() =>
            {
                for (int i = 0; i < 5; i++)
                    Console.Write("C");
            });

            joinThr1.Start();
            joinThr2.Start();

            joinThr1.Join();
            joinThr2.Join();

            joinThr3.Start();

            // Ожидаем завершения последнего потока
            joinThr3.Join();

            // Конец программы
            Console.WriteLine("\nВсе потоки завершены");
        }

        static void LocalWorkItem()
        {
            Console.WriteLine("Hello from static method");
        }

        static void ThreadFunction()
        {
            int count = 3;
            while (count > 0)
            {
                Console.WriteLine("Это дочерний поток программы!");
                --count;
            }
        }
    }
}
