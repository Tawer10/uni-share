﻿using System;
using System.Threading;

class Program
{
    // Для первого примера (глобальные переменные для потоков)
    static long res1, res2;

    // Для второго примера (передача параметров через object)
    static double res;

    static long Factorial(long n)
    {
        long result = 1;
        do
        {
            result *= n;
        } while (--n > 0);
        return result;
    }

    static void ThreadWork(object state)
    {
        string sTitle = ((object[])state)[0] as string;
        double d = (double)(((object[])state)[1]);
        Console.WriteLine(sTitle);
        res = SomeMathOperation(d);
    }

    static double SomeMathOperation(double value)
    {
        // Пример простой операции: квадрат числа
        return value * value;
    }

    static void Main()
    {
        // === Первая часть: Общение через глобальные переменные ===
        long n1 = 5, n2 = 7; // (не ставлю огромные числа как 5000/10000, иначе будет долго считать)

        Thread t1 = new Thread(() =>
        {
            res1 = Factorial(n1);
        });

        Thread t2 = new Thread(() =>
        {
            res2 = Factorial(n2);
        });

        t1.Start();
        t2.Start();
        t1.Join();
        t2.Join();

        Console.WriteLine($"Factorial of {n1} equals {res1}");
        Console.WriteLine($"Factorial of {n2} equals {res2}");

        // === Вторая часть: Передача параметров через object ===
        Thread thr1 = new Thread(ThreadWork);
        thr1.Start(new object[] { "Thread #1", 3.14 });
        thr1.Join();

        Console.WriteLine($"Result of math operation: {res}");

        // === Третья часть: Работа с лямбда-выражениями и проблемой замыкания ===
        for (int i = 0; i < 10; i++)
        {
            int i_copy = i;
            Thread t = new Thread(() =>
            {
                Console.Write("ABCDEFGHIJK"[i_copy]);
            });
            t.Start();
        }
    }
}
