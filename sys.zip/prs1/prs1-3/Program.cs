﻿using System;
using System.Threading;

class Program
{
    static void ThreadFunc(object o)
    {
        for (int i = 0; i < 20; i++)
        {
            Console.Write(o);
            Thread.Sleep(0); // Отдаем квант времени другим потокам
        }
    }

    static void Main()
    {
        // === Пример 1: Приостановка потока через Sleep ===
        Console.WriteLine("Поток приостановлен на 100 мс...");
        Thread.Sleep(100);
        Console.WriteLine("Продолжение работы через 100 мс");

        Console.WriteLine("Поток приостановлен на 5 минут... (симулируем быстро)");
        Thread.Sleep(TimeSpan.FromSeconds(1)); // Чтобы не ждать 5 минут, делаю 1 секунду
        Console.WriteLine("Продолжение работы через 1 секунду");

        // === Пример 2: Параллельная работа потоков без Sleep (нет реальной параллельности) ===
        Console.WriteLine("\nБез вызова Sleep(0) в цикле:");

        Thread[] threadsWithoutSleep = new Thread[4];
        for (int i = 0; i < 4; i++)
            threadsWithoutSleep[i] = new Thread(o =>
            {
                for (int j = 0; j < 20; j++)
                {
                    Console.Write(o);
                    // Здесь Sleep(0) не вызывается
                }
            });

        threadsWithoutSleep[0].Start("A");
        threadsWithoutSleep[1].Start("B");
        threadsWithoutSleep[2].Start("C");
        threadsWithoutSleep[3].Start("D");

        for (int i = 0; i < 4; i++)
            threadsWithoutSleep[i].Join();

        // === Пример 3: Параллельная работа потоков с Sleep(0) (реальная параллельность) ===
        Console.WriteLine("\n\nС вызовом Sleep(0) в цикле:");

        Thread[] threadsWithSleep = new Thread[4];
        for (int i = 0; i < 4; i++)
            threadsWithSleep[i] = new Thread(ThreadFunc);

        threadsWithSleep[0].Start("A");
        threadsWithSleep[1].Start("B");
        threadsWithSleep[2].Start("C");
        threadsWithSleep[3].Start("D");

        for (int i = 0; i < 4; i++)
            threadsWithSleep[i].Join();
    }
}
